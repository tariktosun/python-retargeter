function res=vertcat(X,Y)
res=vertcat(X.data, Y.data);
end
            