This is a simple wrapper class delegating to whatever you initialize it with
in order to test proxying in mlabwrap.
