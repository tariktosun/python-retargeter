function res=eq(X,Y)
res=eq(X.data, Y.data);
end
            