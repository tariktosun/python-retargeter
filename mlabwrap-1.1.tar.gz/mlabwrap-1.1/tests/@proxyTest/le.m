function res=le(X,Y)
res=le(X.data, Y.data);
end
            