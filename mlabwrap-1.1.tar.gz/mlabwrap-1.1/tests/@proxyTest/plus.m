function res=plus(X,Y)
res=plus(X.data, Y.data);
end
            