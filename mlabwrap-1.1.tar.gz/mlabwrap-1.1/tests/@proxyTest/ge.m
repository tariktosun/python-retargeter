function res=ge(X,Y)
res=ge(X.data, Y.data);
end
            