function res=ne(X,Y)
res=ne(X.data, Y.data);
end
            